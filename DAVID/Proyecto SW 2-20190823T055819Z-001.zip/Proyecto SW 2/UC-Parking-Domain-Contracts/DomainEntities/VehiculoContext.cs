﻿/*
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using UC_Parking_Persistence_Contracts.DbEntities;

namespace UC_Parking_Domain_Contracts.DomainEntities
{
    public class VehiculoContext:DbContext
    {
        public VehiculoContext(DbContextOptions<VehiculoContext>options):base(options)
        {
                
        }

        public DbSet<VehiculoDb> VehiculoDomains { get; set; }

    }
}*/
