﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UC_Parking_Persistence_Contracts.Contracts
{
    public interface IUsuarioReposiory
    {
    }
}
