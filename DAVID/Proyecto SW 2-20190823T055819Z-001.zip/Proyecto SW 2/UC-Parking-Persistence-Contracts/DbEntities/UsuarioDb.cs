﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UC_Parking_Persistence_Contracts.DbEntities
{
    public class UsuarioDb
    {
    }
}
